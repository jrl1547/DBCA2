/**
 * Created by cjcot on 4/15/2018.
 */
public class acceptedTable {
    String title, name, abstrac;

    public acceptedTable(String title, String name, String abstrac) {
        this.title = title;
        this.name = name;
        this.abstrac = abstrac;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAbstrac() {
        return abstrac;
    }

    public void setAbstrac(String abstrac) {
        this.abstrac = abstrac;
    }
}
