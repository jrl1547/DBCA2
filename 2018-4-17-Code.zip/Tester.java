   public class Tester{


   public static void main(String[] args){
   
      Users test = new Users("jrl1547");
      test.fetch("jrl1547");
      
      
   
   }
}